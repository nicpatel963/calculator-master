﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CALCULATOR                                                                      //161040107035
{
    public partial class ScientificCalculator : Form
    {
        Double resultValue =0;
        String op_perform = "";
        Nullable<int> flag=null;
        public ScientificCalculator()
        {
            InitializeComponent();
        }
        
        private void button_click(object sender, EventArgs e)                  // button click
        {
            
            if (textBoxResult.Text == "0" || flag == 1)
                  textBoxResult.Clear();   
            flag = 0;
            Button b = (Button)sender;
            if (b.Text == ".")
            {
                if (!textBoxResult.Text.Contains("."))
                    textBoxResult.Text = textBoxResult.Text + b.Text;
            }
            else
                textBoxResult.Text = textBoxResult.Text + b.Text;
        }

        private void btnPlus_Click(object sender, EventArgs e)              //button plus
        {
       
            op_perform = "+";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " +"+";
            flag = 1;

        }
        private void btnMinus_Click(object sender, EventArgs e)             // button minus
        {
            op_perform = "-";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + "-";
            flag = 1;
        }
        private void btnMultiply_Click(object sender, EventArgs e)         // button multiply 
        {
       
            op_perform = "*";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + "*";
            flag = 1;
        }
        private void btnDivison_Click(object sender, EventArgs e)           // button divison
        {
            if (op_perform == "+" && flag != 1) textBoxResult.Text = Convert.ToString(resultValue + Double.Parse(textBoxResult.Text)); if (op_perform == "-" && flag != 1) textBoxResult.Text = Convert.ToString(resultValue - Double.Parse(textBoxResult.Text)); if (op_perform == "*" && flag != 1) textBoxResult.Text = Convert.ToString(resultValue * Double.Parse(textBoxResult.Text)); if (op_perform == "/" && flag != 1) textBoxResult.Text = Convert.ToString(resultValue / Double.Parse(textBoxResult.Text));
            op_perform = "/";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + "/";
            flag = 1;
        }

        private void button19_Click(object sender, EventArgs e)                 // CE button
        {

            textBoxResult.Text = "0";
        }

        private void button18_Click(object sender, EventArgs e)                 // C button
        {
            textBoxResult.Text = "0";
            resultValue = 0;
            lblCurrent.Text = "";
            
        }

        private void button17_Click(object sender, EventArgs e)                 // equals to button
        {
            
            switch (op_perform)
            {

                case "+":
                    textBoxResult.Text = Convert.ToString(resultValue + Double.Parse(textBoxResult.Text));
                    break;
                case "-":
                    textBoxResult.Text = Convert.ToString(resultValue - Double.Parse(textBoxResult.Text));
                    break;
                case "*":
                    textBoxResult.Text = Convert.ToString(resultValue * Double.Parse(textBoxResult.Text));
                    break;
                case "/":
                    textBoxResult.Text = Convert.ToString(resultValue / Double.Parse(textBoxResult.Text));
                    break;
                case "1":               //x power y
                       double ans = Math.Pow(resultValue, Convert.ToDouble(textBoxResult.Text));
                        textBoxResult.Text = Convert.ToString(ans);  
                    break;
                case "2":               // x*x     
                    textBoxResult.Text = Convert.ToString(Convert.ToDouble(textBoxResult.Text) * Convert.ToDouble(textBoxResult.Text));
                    break;
                case "3":case "4":case "5":case "6":case "7":case "8":case "9":case "10":case "11":
                    lblCurrent.Text = Convert.ToString(resultValue);    
                        break;
                default:
                    break;
            }
            lblCurrent.Text = textBoxResult.Text;
            flag = 1;
            op_perform = "=";
        }

        private void btnDelete_Click(object sender, EventArgs e)                // button delete
        {
            String s = textBoxResult.Text;
            if (s.Length != 0)
            {
                textBoxResult.Text = s.Substring(0, s.Length - 1);
               
            }
        }

        private void btnxx_Click(object sender, EventArgs e)
        {
            if (flag == 1)
                textBoxResult.Text = "syntax error";
            else
                textBoxResult.Text = Convert.ToString(Convert.ToInt32(textBoxResult.Text) * Convert.ToInt32(textBoxResult.Text));
            lblCurrent.Text = textBoxResult.Text;
        }

        private void btnStandard_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }
       
        private void btnxx_Click_1(object sender, EventArgs e)          // button x*x
        {
            op_perform = "2";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + "^2";
            flag = 1; 
        }

        private void btnxy_Click(object sender, EventArgs e)
        {
            flag = 1;
            op_perform = "1";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + "^";
        }

        private void btnMod_Click(object sender, EventArgs e)           //button mod(underroot)
        {
            flag = 1;
            op_perform = "3";
            resultValue = Double.Parse(textBoxResult.Text);
            double ans = Math.Sqrt(resultValue);
            textBoxResult.Text = Convert.ToString(ans);

        }

        private void btnpie_Click(object sender, EventArgs e)           // button pie
        {
            if (textBoxResult.Text == "0" || flag == 1)
                textBoxResult.Clear();
            flag = 1;
            textBoxResult.Text = Convert.ToString(Math.PI);
        }

        private void btnN_Click(object sender, EventArgs e)             // button n!
        {
            flag = 1;
            op_perform = "4";
            double ans = 1.0;
            lblCurrent.Text ="factorial("+textBoxResult.Text+")";
            for (int i = 1; i < Convert.ToDouble(textBoxResult.Text); i++)
                ans = ans * i;
            textBoxResult.Text = Convert.ToString(ans);            
        }

        private void btnSin_Click(object sender, EventArgs e)               // button sin
        {
            flag = 1;
            op_perform = "5";
            lblCurrent.Text = "sin(" + textBoxResult.Text + ")";
            textBoxResult.Text =Convert.ToString(Math.Sin(Convert.ToDouble(textBoxResult.Text)));
        }

        private void btnCos_Click(object sender, EventArgs e)               // button cos
        {
            flag = 1;
            op_perform = "6";
            lblCurrent.Text = "cos(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Cos(Convert.ToDouble(textBoxResult.Text)));
        }

        private void btnTan_Click(object sender, EventArgs e)               // button tan
        {
            flag = 1;
            op_perform = "7";
            lblCurrent.Text = "tan(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Tan(Convert.ToDouble(textBoxResult.Text)));
        }

        private void btnSinh_Click(object sender, EventArgs e)              // button sinh
        {
            flag = 1;
            op_perform = "8";
            lblCurrent.Text = "sinh(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Sinh(Convert.ToDouble(textBoxResult.Text)));

        }
        private void btnCosh_Click(object sender, EventArgs e)              // button cosh
        {
            flag = 1;
            op_perform = "9";
            lblCurrent.Text = "cosh(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Cosh(Convert.ToDouble(textBoxResult.Text)));

        }
             private void btnTanh_Click(object sender, EventArgs e)              // button tanh
        {
            flag = 1;
            op_perform = "10";
            lblCurrent.Text = "tanh(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Tanh(Convert.ToDouble(textBoxResult.Text)));

        }

        private void btnLog_Click(object sender, EventArgs e)                   // button log
        {
            flag = 1;
            op_perform = "11";
            lblCurrent.Text = "log(" + textBoxResult.Text + ")";
            textBoxResult.Text = Convert.ToString(Math.Log10(Convert.ToDouble(textBoxResult.Text)));
        }

        private void ScientificCalculator_Load(object sender, EventArgs e)
        {
            this.Width = 438;
            textBoxResult.Width = 357;
        }

        private void standardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 438;
            textBoxResult.Width = 357;
        }

        private void scientificToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Width = 670;
            textBoxResult.Width = 584;
        }
    }
    
}



