﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CALCULATOR
{
    public partial class Form1 : Form
    {
        Double resultValue = 0;
        String op_perform = "";
        int flag = 0;
            public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)                  // button click
        {
          

            if (textBoxResult.Text == "0" || flag==1)
                textBoxResult.Clear();

            Button button = (Button)sender;
            textBoxResult.Text = textBoxResult.Text + button.Text;
            flag = 0;
        }

        private void operator_click(object sender, EventArgs e)               //operator perform
        {
            Button button = (Button)sender;
            op_perform = button.Text;
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + op_perform;


            //textBoxResult.Text = "0";
            flag = 1;
        }
        private void xPowery_click(object sender, EventArgs e)              // x power y
        {
            Button button = (Button)sender;
            op_perform = "a";
            resultValue = Double.Parse(textBoxResult.Text);
            lblCurrent.Text = resultValue + " " + op_perform;

        }

        private void button19_Click(object sender, EventArgs e)                 // CE button
        {
        
            textBoxResult.Text = "0";
        }

        private void button18_Click(object sender, EventArgs e)                 // C button
        {
            textBoxResult.Text = "0";
            resultValue = 0;
            lblCurrent.Text = "";

        }

        private void button17_Click(object sender, EventArgs e)                 // equals to button
        {

            switch (op_perform)
            {
                   
                case "+":
                    textBoxResult.Text =Convert.ToString(resultValue + Double.Parse(textBoxResult.Text));
                    break;
                case "-":
                    textBoxResult.Text = Convert.ToString(resultValue - Double.Parse(textBoxResult.Text));
                    break;
                case "*":
                    textBoxResult.Text = Convert.ToString(resultValue * Double.Parse(textBoxResult.Text));
                    break;
                case "/":
                    textBoxResult.Text = Convert.ToString(resultValue / Double.Parse(textBoxResult.Text));
                    break;
                case "1":
                    textBoxResult.Text = Convert.ToString(Convert.ToDouble(textBoxResult.Text) * Convert.ToDouble(textBoxResult.Text));
                    break;
                default:
                    break;
            }
            lblCurrent.Text =textBoxResult.Text;
            flag = 1;
        }

        private void btnDelete_Click(object sender, EventArgs e)                // button delete
        {
            String s = textBoxResult.Text;
            if (s.Length != 0)
            {
                textBoxResult.Text = s.Substring(0, s.Length - 1);
            }
        }

        private void btnxx_Click(object sender, EventArgs e)
        {
            if (flag == 1)
                textBoxResult.Text = "syntax error";
            else
                textBoxResult.Text = Convert.ToString(Convert.ToInt32(textBoxResult.Text) *Convert.ToInt32 (textBoxResult.Text));
            lblCurrent.Text = textBoxResult.Text;
        }

        private void btnScientific_Click(object sender, EventArgs e)
        {
            ScientificCalculator s = new ScientificCalculator();
            this.Hide();
            s.Show();

        }
    }
}
